var vie_pock = 100;
function vie() {


}

function vive_attaque() {

    var vive_attaque1 = Math.round(Math.random() * 10);
    if (vie_pock > 0) {
        vie_pock = vie_pock - vive_attaque1;
        if (vie_pock <= 0) {
            vie_pock = 0
        }
        document.getElementById('pointdevie').innerHTML = vie_pock;
        document.getElementById('pointdevie').style.width = vie_pock + "%";
        if (vie_pock <= 50) {
            document.getElementById('pointdevie').style.backgroundColor = "yellow";
            document.getElementById('pointdevie').style.color = "black";
            if (vie_pock <= 30) {
                document.getElementById('pointdevie').style.backgroundColor = "red";
                document.getElementById('pointdevie').style.color = "black";

            }
        }
    }

}
function flammeche() {
    var flammeche1 = Math.round(Math.random() * 20);
    if (vie_pock > 0) {
        vie_pock = vie_pock - flammeche1;
        if (vie_pock <= 0) {
            vie_pock = 0

        }
        document.getElementById('pointdevie').innerHTML = vie_pock;
        document.getElementById('pointdevie').style.width = vie_pock + "%";
        if (vie_pock <= 50) {
            document.getElementById('pointdevie').style.backgroundColor = "yellow";
            document.getElementById('pointdevie').style.color = "black";
            if (vie_pock <= 30) {
                document.getElementById('pointdevie').style.backgroundColor = "red";
                document.getElementById('pointdevie').style.color = "black";
                if (vie_pock <= 0) {
                    vie_pock = 0 + "%";
                }
            }
        }
    }

}
function lance_flamme() {
    var lance_flamme1 = Math.round(Math.random() * 40);
    if (vie_pock > 0) {
        vie_pock = vie_pock - lance_flamme1;
        if (vie_pock <= 0) {
            vie_pock = 0;
        }
        document.getElementById('pointdevie').innerHTML = vie_pock;
        document.getElementById('pointdevie').style.width = vie_pock + "%";
        if (vie_pock <= 50) {
            document.getElementById('pointdevie').style.backgroundColor = "yellow";
            document.getElementById('pointdevie').style.color = "black";
            if (vie_pock <= 30) {
                document.getElementById('pointdevie').style.backgroundColor = "red";
                document.getElementById('pointdevie').style.color = "black";



            }
        }

    }

}
function deflagration() {
    var deflagration1 = Math.round(Math.random() * 50);
    if (vie_pock > 0) {
        vie_pock = vie_pock - deflagration1;
        if (vie_pock <= 0) {
            vie_pock = 0
        }
        document.getElementById('pointdevie').innerHTML = vie_pock;
        document.getElementById('pointdevie').style.width = vie_pock + "%";
        if (vie_pock <= 50) {
            document.getElementById('pointdevie').style.backgroundColor = "yellow";
            document.getElementById('pointdevie').style.color = "black";
            if (vie_pock <= 30) {
                document.getElementById('pointdevie').style.backgroundColor = "red";
                document.getElementById('pointdevie').style.color = "black";

            }

        }

    }

}